package com.dave.arrayreverser.service;

public interface ArrayFlattener
{
   public Integer [] flatten(Integer [][] input);
}
