package com.dave.arrayflattener;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(ArrayFlattenerTest.class)
public class TestSuite
{

}
